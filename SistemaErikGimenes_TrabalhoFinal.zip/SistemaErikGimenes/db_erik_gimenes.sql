-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.4.32-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             12.8.0.6908
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for db_erik_gimenes
DROP DATABASE IF EXISTS `db_erik_gimenes`;
CREATE DATABASE IF NOT EXISTS `db_erik_gimenes` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;
USE `db_erik_gimenes`;

-- Dumping structure for table db_erik_gimenes.eg_clientes
DROP TABLE IF EXISTS `eg_clientes`;
CREATE TABLE IF NOT EXISTS `eg_clientes` (
  `eg_idClientes` int(11) NOT NULL AUTO_INCREMENT,
  `eg_nomeCompleto` varchar(100) DEFAULT NULL,
  `eg_cpf` varchar(14) DEFAULT NULL,
  `eg_rg` varchar(12) DEFAULT NULL,
  `eg_dataNascimento` date DEFAULT NULL,
  `eg_email` varchar(100) DEFAULT NULL,
  `eg_telefone` varchar(15) DEFAULT NULL,
  `eg_celular` varchar(15) DEFAULT NULL,
  `eg_cep` varchar(9) DEFAULT NULL,
  `eg_endereco` varchar(100) DEFAULT NULL,
  `eg_numero` varchar(10) DEFAULT NULL,
  `eg_complemento` varchar(50) DEFAULT NULL,
  `eg_bairro` varchar(50) DEFAULT NULL,
  `eg_cidade` varchar(50) DEFAULT NULL,
  `eg_estado` varchar(2) DEFAULT NULL,
  `eg_dataCadastro` datetime DEFAULT NULL,
  `eg_ativo` char(1) DEFAULT NULL,
  PRIMARY KEY (`eg_idClientes`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table db_erik_gimenes.eg_funcionarios
DROP TABLE IF EXISTS `eg_funcionarios`;
CREATE TABLE IF NOT EXISTS `eg_funcionarios` (
  `eg_idFuncionarios` int(11) NOT NULL AUTO_INCREMENT,
  `eg_nome` varchar(50) DEFAULT NULL,
  `eg_apelido` varchar(25) DEFAULT NULL,
  `eg_cpf` varchar(14) DEFAULT NULL,
  `eg_email` varchar(50) DEFAULT NULL,
  `eg_salario` decimal(7,2) DEFAULT NULL,
  `eg_ativo` char(1) DEFAULT NULL,
  PRIMARY KEY (`eg_idFuncionarios`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table db_erik_gimenes.eg_produtos
DROP TABLE IF EXISTS `eg_produtos`;
CREATE TABLE IF NOT EXISTS `eg_produtos` (
  `eg_idProdutos` int(11) NOT NULL AUTO_INCREMENT,
  `eg_nome` varchar(100) DEFAULT NULL,
  `eg_descricao` text DEFAULT NULL,
  `eg_quantidade` int(11) DEFAULT NULL,
  `eg_precoUnidade` decimal(10,2) DEFAULT NULL,
  `eg_tipo` varchar(10) DEFAULT NULL,
  `eg_dataCadastro` date DEFAULT NULL,
  PRIMARY KEY (`eg_idProdutos`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table db_erik_gimenes.eg_usuarios
DROP TABLE IF EXISTS `eg_usuarios`;
CREATE TABLE IF NOT EXISTS `eg_usuarios` (
  `fhf_idUsuarios` int(11) NOT NULL AUTO_INCREMENT,
  `fhf_nome` varchar(50) NOT NULL,
  `fhf_apelido` varchar(25) NOT NULL,
  `fhf_cpf` varchar(14) NOT NULL,
  `fhf_dataNascimento` date NOT NULL,
  `fhf_senha` varchar(255) NOT NULL,
  `fhf_nivel` int(11) NOT NULL,
  `fhf_ativo` char(1) DEFAULT NULL,
  PRIMARY KEY (`fhf_idUsuarios`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;

-- Data exporting was unselected.

-- Dumping structure for table db_erik_gimenes.eg_venda
DROP TABLE IF EXISTS `eg_venda`;
CREATE TABLE IF NOT EXISTS `eg_venda` (
  `eg_idVendas` int(11) NOT NULL AUTO_INCREMENT,
  `eg_fkidClientes` int(11) DEFAULT NULL,
  `eg_dataVenda` date DEFAULT NULL,
  `eg_formaPagamento` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`eg_idVendas`),
  KEY `eg_fkidClientes` (`eg_fkidClientes`),
  CONSTRAINT `eg_fkidClientes` FOREIGN KEY (`eg_fkidClientes`) REFERENCES `eg_clientes` (`eg_idClientes`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table db_erik_gimenes.eg_vendaprodutos
DROP TABLE IF EXISTS `eg_vendaprodutos`;
CREATE TABLE IF NOT EXISTS `eg_vendaprodutos` (
  `eg_fkidVenda` int(11) DEFAULT NULL,
  `eg_fkidProdutos` int(11) DEFAULT NULL,
  KEY `eg_fkidVenda` (`eg_fkidVenda`),
  KEY `eg_fkidProdutos` (`eg_fkidProdutos`),
  CONSTRAINT `eg_fkidProdutos` FOREIGN KEY (`eg_fkidProdutos`) REFERENCES `eg_produtos` (`eg_idProdutos`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `eg_fkidVenda` FOREIGN KEY (`eg_fkidVenda`) REFERENCES `eg_venda` (`eg_idVendas`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
