-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.4.32-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             12.8.0.6908
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for db_erik_gimenes
DROP DATABASE IF EXISTS `db_erik_gimenes`;
CREATE DATABASE IF NOT EXISTS `db_erik_gimenes` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;
USE `db_erik_gimenes`;

-- Dumping structure for table db_erik_gimenes.eg_clientes
DROP TABLE IF EXISTS `eg_clientes`;
CREATE TABLE IF NOT EXISTS `eg_clientes` (
  `eg_idClientes` int(11) NOT NULL AUTO_INCREMENT,
  `eg_nomeCompleto` varchar(100) DEFAULT NULL,
  `eg_cpf` varchar(14) DEFAULT NULL,
  `eg_rg` varchar(12) DEFAULT NULL,
  `eg_dataNascimento` date DEFAULT NULL,
  `eg_email` varchar(100) DEFAULT NULL,
  `eg_telefone` varchar(15) DEFAULT NULL,
  `eg_celular` varchar(15) DEFAULT NULL,
  `eg_cep` varchar(9) DEFAULT NULL,
  `eg_endereco` varchar(100) DEFAULT NULL,
  `eg_numero` varchar(10) DEFAULT NULL,
  `eg_complemento` varchar(50) DEFAULT NULL,
  `eg_bairro` varchar(50) DEFAULT NULL,
  `eg_cidade` varchar(50) DEFAULT NULL,
  `eg_estado` varchar(2) DEFAULT NULL,
  `eg_dataCadastro` datetime DEFAULT NULL,
  `eg_ativo` char(1) DEFAULT NULL,
  PRIMARY KEY (`eg_idClientes`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table db_erik_gimenes.eg_funcionarios
DROP TABLE IF EXISTS `eg_funcionarios`;
CREATE TABLE IF NOT EXISTS `eg_funcionarios` (
  `eg_idFuncionarios` int(11) NOT NULL AUTO_INCREMENT,
  `eg_nome` varchar(50) DEFAULT NULL,
  `eg_apelido` varchar(25) DEFAULT NULL,
  `eg_cpf` varchar(14) DEFAULT NULL,
  `eg_email` varchar(50) DEFAULT NULL,
  `eg_salario` decimal(7,2) DEFAULT NULL,
  `eg_ativo` char(1) DEFAULT NULL,
  PRIMARY KEY (`eg_idFuncionarios`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table db_erik_gimenes.eg_produtos
DROP TABLE IF EXISTS `eg_produtos`;
CREATE TABLE IF NOT EXISTS `eg_produtos` (
  `eg_idProdutos` int(11) NOT NULL AUTO_INCREMENT,
  `eg_nome` varchar(100) DEFAULT NULL,
  `eg_descricao` text DEFAULT NULL,
  `eg_quantidade` int(11) DEFAULT NULL,
  `eg_precoUnidade` decimal(10,2) DEFAULT NULL,
  `eg_tipo` varchar(10) DEFAULT NULL,
  `eg_dataCadastro` date DEFAULT NULL,
  PRIMARY KEY (`eg_idProdutos`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table db_erik_gimenes.eg_usuarios
DROP TABLE IF EXISTS `eg_usuarios`;
CREATE TABLE IF NOT EXISTS `eg_usuarios` (
  `id_usuario` int(11) NOT NULL AUTO_INCREMENT,
  `nome_completo` varchar(150) NOT NULL,
  `apelido` varchar(150) NOT NULL,
  `cpf` varchar(20) NOT NULL,
  `data_nascimento` date NOT NULL,
  `senha` varchar(50) NOT NULL,
  `nivel_acesso` int(11) NOT NULL,
  `ativo` char(1) DEFAULT NULL,
  PRIMARY KEY (`id_usuario`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;

-- Data exporting was unselected.

-- Dumping structure for table db_erik_gimenes.eg_vendedor
DROP TABLE IF EXISTS `eg_vendedor`;
CREATE TABLE IF NOT EXISTS `eg_vendedor` (
  `eg_idVendedor` int(11) NOT NULL AUTO_INCREMENT,
  `eg_nome` varchar(100) DEFAULT NULL,
  `eg_cpf` varchar(14) DEFAULT NULL,
  `eg_telefone` varchar(15) DEFAULT NULL,
  `eg_email` varchar(100) DEFAULT NULL,
  `eg_ativo` char(1) DEFAULT NULL,
  PRIMARY KEY (`eg_idVendedor`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table db_erik_gimenes.eg_vendas
DROP TABLE IF EXISTS `eg_vendas`;
CREATE TABLE IF NOT EXISTS `eg_vendas` (
  `id_venda` int(11) NOT NULL AUTO_INCREMENT,
  `fk_cliente` int(11) DEFAULT NULL,
  `fk_vendedor` int(11) DEFAULT NULL,
  `data_venda` date DEFAULT NULL,
  `valor_total` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id_venda`),
  KEY `fk_cliente` (`fk_cliente`),
  KEY `fk_vendedor` (`fk_vendedor`),
  CONSTRAINT `fk_cliente` FOREIGN KEY (`fk_cliente`) REFERENCES `eg_clientes` (`eg_idClientes`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_vendedor` FOREIGN KEY (`fk_vendedor`) REFERENCES `eg_vendedor` (`eg_idVendedor`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table db_erik_gimenes.eg_vendas_produtos
DROP TABLE IF EXISTS `eg_vendas_produtos`;
CREATE TABLE IF NOT EXISTS `eg_vendas_produtos` (
  `id_venda_produto` int(11) NOT NULL AUTO_INCREMENT,
  `fk_venda` int(11) DEFAULT NULL,
  `fk_produto` int(11) DEFAULT NULL,
  `quantidade` int(11) DEFAULT NULL,
  `valor_unitario` decimal(8,2) DEFAULT NULL,
  `valor_total` decimal(8,2) DEFAULT NULL,
  PRIMARY KEY (`id_venda_produto`),
  KEY `fk_venda` (`fk_venda`),
  KEY `fk_produto` (`fk_produto`),
  CONSTRAINT `fk_produto` FOREIGN KEY (`fk_produto`) REFERENCES `eg_produtos` (`eg_idProdutos`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_venda` FOREIGN KEY (`fk_venda`) REFERENCES `eg_vendas` (`id_venda`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table db_erik_gimenes.eg_compras
DROP TABLE IF EXISTS `eg_compras`;
CREATE TABLE IF NOT EXISTS `eg_compras` (
  `id_compra` int(11) NOT NULL AUTO_INCREMENT,
  `fk_fornecedor` int(11) DEFAULT NULL,
  `data_compra` date DEFAULT NULL,
  `valor_total` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id_compra`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table db_erik_gimenes.eg_compras_produtos
DROP TABLE IF EXISTS `eg_compras_produtos`;
CREATE TABLE IF NOT EXISTS `eg_compras_produtos` (
  `id_compra_produto` int(11) NOT NULL AUTO_INCREMENT,
  `fk_compra` int(11) DEFAULT NULL,
  `fk_produto` int(11) DEFAULT NULL,
  `quantidade` int(11) DEFAULT NULL,
  `valor_unitario` decimal(8,2) DEFAULT NULL,
  `valor_total` decimal(8,2) DEFAULT NULL,
  PRIMARY KEY (`id_compra_produto`),
  KEY `fk_compra` (`fk_compra`),
  KEY `fk_produto_compra` (`fk_produto`),
  CONSTRAINT `fk_compra` FOREIGN KEY (`fk_compra`) REFERENCES `eg_compras` (`id_compra`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_produto_compra` FOREIGN KEY (`fk_produto`) REFERENCES `eg_produtos` (`eg_idProdutos`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Inserir usuário padrão para teste de login
-- CPF: 12345678900, Senha: admin123
INSERT INTO `eg_usuarios` (`nome_completo`, `apelido`, `cpf`, `data_nascimento`, `senha`, `nivel_acesso`, `ativo`) 
VALUES ('Administrador do Sistema', 'Admin', '12345678900', '1990-01-01', 'admin123', 1, 'S');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
